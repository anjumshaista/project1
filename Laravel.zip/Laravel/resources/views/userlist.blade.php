
@extends('layout')

@section('content')
<h1>User Page</h1>
@endsection