
@extends('layout')

@section('content')
<h1>Account Page</h1>
@endsection