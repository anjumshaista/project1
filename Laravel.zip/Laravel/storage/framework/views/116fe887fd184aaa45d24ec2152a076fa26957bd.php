


<?php $__env->startSection('content'); ?>
<div class ="container">
<h1>Login Page</h1>
<form action="/loginsubmit" method="POST">

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="text" class="form-control"  id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control"  id="pwd">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Laravel\Laravel\resources\views/login.blade.php ENDPATH**/ ?>