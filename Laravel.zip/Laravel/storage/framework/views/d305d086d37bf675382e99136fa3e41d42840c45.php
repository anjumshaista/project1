<html>
<head>
<script src="<?php echo e(asset('js/app.js')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
 integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<div class="header">
<?php $__env->startSection('header'); ?>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Navbar</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="list">User List </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create">Create Account</a>
      </li>
    </ul>
  </div>
</nav>
<?php echo $__env->yieldSection(); ?>
</div>
<div class="content">
<?php $__env->startSection('content'); ?>
<h1>Content Part</h1>
<?php echo $__env->yieldSection(); ?>
</div>
<div class="footer">
<?php $__env->startSection('footer'); ?>
<h1>Footer Part</h1>
<?php echo $__env->yieldSection(); ?>
</div>

</body>
</html><?php /**PATH F:\xampp\htdocs\Laravel\Laravel\resources\views/layout.blade.php ENDPATH**/ ?>